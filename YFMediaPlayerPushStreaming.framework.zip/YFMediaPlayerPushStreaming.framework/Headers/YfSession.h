//
//  YfSession.h
//  YFMediaPlayerPushStreaming
//
//  Created by suntongmian@163.com
//  Copyright (c) 2015年 YunFan. All rights reserved.
//

/**
 * SDK current version : v4.3.5
 */

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreVideo/CoreVideo.h>
#import <CoreMedia/CoreMedia.h>
#import "YfMCamera.h"

@class YfSession;

typedef void(^audioRecoderError)(NSString *error,OSStatus status);

typedef void(^PixelCallBack)(CVPixelBufferRef pixelbuffer);

typedef void(^gifCallBack)(CFURLRef GifFileURL);

typedef NS_ENUM(NSInteger, YfSessionState)
{
    YfSessionStateNone,
    YfSessionStatePreviewStarted,
    YfSessionStateStarting,
    YfSessionStateStarted,
    YfSessionStateEnded,
    YfSessionStateError
};

typedef NS_ENUM(NSInteger, YfCameraState)
{
    YfCameraStateFront,
    YfCameraStateBack
};

typedef NS_ENUM(NSInteger,YfOutPutImageOrientation){
    
    YfOutPutImageOrientationNormal,               //直屏
    YfOutPutImageOrientationLandLeftFullScreen,   //左全屏
    YfOutPutImageOrientationLandRightFullScreen   //右全屏
    
};

typedef NS_ENUM(int,YfTransportStyle){
    
    YfTransportNone,//默认
    YfTransportUDP,//使用UDP
    YfTransportFEC//使用FEC
    
};


@protocol YfSessionDelegate <NSObject>
@required
- (void) connectionStatusChanged: (YfSessionState) sessionState;


@optional
- (void)yfsessionUploadSpeed:(int32_t)uploadSpeed;


@optional
- (void)yfPushStreamingCameraSource:(CVPixelBufferRef)pixelbuffer size:(size_t)pixelbufferSize;
//@required
//- (CVPixelBufferRef)yfPushStreamingCameraSourceOutput:(CVPixelBufferRef)pixelBufferRef size:(size_t)pixelBufferSize;
@end

@protocol YfSessionCameraSourceDataDelegate <NSObject>
- (void)cameraSourceData:(CVPixelBufferRef)pixelBufferRef size:(size_t)pixelBufferSize;
@end

@interface YfSession : NSObject
@property (nonatomic, readonly) YfSessionState rtmpSessionState;
@property (nonatomic, assign) id<YfSessionDelegate> delegate;
@property (nonatomic, assign) id<YfSessionCameraSourceDataDelegate> dataDelegate;

@property (nonatomic, strong, readonly) UIView* previewView; // 摄像头视图
@property (nonatomic, assign) YfCameraState cameraState; // 前后摄像头切换
@property (nonatomic, assign) BOOL torch; // YES：闪光灯打开，NO：关闭

@property(nonatomic,assign)BOOL isBeautify; //YES 开启美颜 NO:关闭美颜 //默认无美颜

@property (nonatomic,assign) BOOL  IsAudioOpen;//YES:推流音频 NO:不推流音频   默认NO

@property (nonatomic,assign)BOOL isHeadPhonesPlay; //默认NO     打开为YES

//暂时弃用
@property (nonatomic,assign) BOOL IsAutoFitBitRate; //YES：自适应开启    NO默认 自适应关闭


@property (nonatomic,readonly) int64_t m_bufferSize;  //当前缓存大小


@property (nonatomic,assign)BOOL isPlayerCameraMirror;   //默认镜像 YES


@property (nonatomic,assign)int uploadSpeedCountTime;

//相机
@property (nonatomic, assign,readonly) YfMCamera *metalCamera;

//自适应码率接口
@property (nonatomic, assign) BOOL isOpenAdaptaBitrate;

//当前录制时长(单位秒)
@property (nonatomic, assign) CGFloat currentDts;

/**
 * 函数功能：录制短视频回调  （操作视频比如合成裁剪之类的结果都是通过该回调）
 * task_id : 任务标记
 * result :操作结果
 * outputPath :输出路径
 */
@property (nonatomic, copy) void (^recordCallBack)(int taskId, int result, NSString * outputPath);

//录制失败回调  APP层只需处理UI即可（录制太短可能录制失败）
@property (nonatomic, copy) void (^failCallBack)();

/**
 * 函数功能：获取SDK版本号
 * 返回值类型：NSString
 */
+ (NSString *) getYfSDKVersion;

/**
 * 函数功能：获取相机输出的图像数据
 * pixelBufferRef : 相机的图像数据
 */
- (void)receivePushStreamingCameraSourceOutput:(CVPixelBufferRef)pixelBufferRef size:(size_t)pixelBufferSize;
- (void)receivePushStreamingCameraSourceSBOutput:(CMSampleBufferRef)sampleBufferRef size:(size_t)sampleBufferSize;


/**
 * url : rtmp推流地址
 */
- (void) startRtmpSessionWithRtmpURL:(NSString*)url; // URL : url

/**
 * 停止rtmp session，不释放资源，会触发rtmp session结束通知
 */
- (void) endRtmpSession;

/**
 * 停止rtmp session，不释放资源，不会触发rtmp session结束通知
 */
- (void) shutdownRtmpSession;
/**
 * 停止rtmp session，释放资源，不会触发rtmp session结束通知
 */
- (void) releaseRtmpSession;

/**
 *  网络错误／无网络的时候中断推流 更新推流器状态
 */
- (void)ShutErrorRtmpSession;

//手动聚焦点
- (void)focusAtPoint:(CGPoint)point;

//传入ip传
- (char *)GetDNSIP:(char *)ipStr;

//重新设置码率 （最低400000,小于默认为400000）
- (void)reSetBitarate:(int)bps;

//重新设置帧率
- (void)reSetFrameRate:(int)fps;
//开启log保存在本地Documents
- (void)openLog:(BOOL)isOpen;

/**
 * 函数功能：初始化推流参数
 * videoSize : 编码视频的宽度, 高度
 * captureSessionPreset :相机采集尺寸
 * fps       : 帧率
 * bps       : 码率
 * bufferTime : 推流缓存时间 默认推荐 3s  取值范围 2-8
 * isDropFrame :/YES 丢帧   NO:不丢帧
 * isOnlyAudioPushBuffer: 是否纯音频推流  默认0
 * audioRecoderError :音频录音出错回调
 * isOpenAdapta 开启/关闭 自适应码率
 */

- (instancetype) initWithVideoSize:(CGSize)videoSize sessionPreset:(NSString *)captureSessionPreset frameRate:(int)fps bitrate:(int)bps bufferTime:(int)bufferTime isUseUDP:(YfTransportStyle)transportStyle isDropFrame:(BOOL)isDropFrame YfOutPutImageOrientation:(YfOutPutImageOrientation)YfOutPutImageOrientation isOnlyAudioPushBuffer:(BOOL)isOnlyAudioPushBuffer audioRecoderError:(audioRecoderError)audioRecoderError isOpenAdaptBitrate:(BOOL)isOpenAdapta;

#pragma mark -----  录制短视频方法
/**
 * rtmpUrl :   本地录制地址
 * streamKey : 如果是本地录制 请填写格式 目前支持 @"mp4" @"flv" 短视频仅支持@"mp4"
 */
- (void) startRecordWithURL:(NSString*) recordUrl
               andStreamKey:(NSString*) streamKey; // URL: rtmpUrl/streamKey

/**
 * 停止录制，不释放资源，会触发结束通知
 */
- (void) pauseRecord;

//接收短视频录制或连麦者播放器音频数据
- (void) recevieAudioData:(NSData *)audioData size:(size_t)audioDataSize;

- (void) recevieAudioData:(NSData *)audioData size:(size_t)audioDataSize rate:(float)playeRate;

//清空音频队列
- (void) flushPlayerAudioData;

//合成视频   
- (int) MediaConcatTaskId:(int)taskId;

- (void) MediaContactInputArr:(NSArray *)arr outPutPath:(NSString *)output AndTaskId:(int)taskId;

/**
 * 函数功能：裁剪视频
 * outputFile : 裁剪后输出的文件路径
 * inputFile : 将要裁剪的文件
 * startTime : 从哪开始裁剪
 * endTime : 结束的裁剪时间
 * taskId : 任务ID
 */
- (int) MediaSplitOutPutFile:(NSString *)outputFile AndInputFile:(NSString *)inputFile startTime:(int)startTime endTime:(int)endTime taskId:(int)taskId;

/**
 * 函数功能：将音频和视频合成
 * VideoFileName : 将要合成的视频轨文件
 * audioFileName : 将要合成的音频轨文件
 * fileName : 生成后保存的文件路径
 * value : 传入的音频文件从第几秒开始
 * taskId : 任务ID
 */
- (void) MeidaAddAudioDataAndVideoFileName:(NSString *)VideoFileName AndAudioFileName:(NSString *)audioFileName AndOutPutName:(NSString *)fileName AndSeekTime:(CGFloat)value AndTaskId:(int)taskId;

//获取缩略图
- (void) MediaGetThumnailOutPutFile:(NSString *)outPutFile AndInputFile:(NSString *)inputFile interval:(int)interval taskId:(int)taskId;

//时光倒流效果
- (void) MediaReverseVideo:(NSString *)inputFile outPutFile:(NSString *)outPutFile taskId:(int)taskId;

/**
 * 函数功能：转码，转码后帧率将会保持一致
 * inputFile : 输入文件
 * ouputFile : 输出文件
 * bitrate : 目标码率
 * rate : 帧率
 * taskId : 任务ID
 */

- (void) MediaChangeCode:(NSString *)inputFile outputFile:(NSString *)ouputFile BitRate:(int)bitrate Rate:(int)rate taskId:(int)taskId;

//删除最后一段视频
- (void)deleteLastMediaObject;

//第一次开始传入路径后，后续可以直接调此接口让sdk管理文件路径，也可以自己调用上面的startRecordWithURL:andStreamKey自己管理文件路径
- (void)resumeRecord;

@end
