//
//  3DTextureMap.h
//  opengles
//
//  Created by 张涛 on 2017/3/21.
//  Copyright © 2017年 张涛. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <CoreMedia/CoreMedia.h>

typedef void(^GifCallBack)(CFURLRef GifFileURL);

typedef void(^BufferCallBack)(CVPixelBufferRef pixelbuffer);

typedef enum : NSUInteger {
    
    YfPreviewViewLogoPostitionleftUp,
    YfPreviewViewLogoPostitionleftDown,
    YfPreviewViewLogoPostitionrightUp,
    YfPreviewViewLogoPostitionrightDown,
    
} YfPreviewViewLogoPostition;


typedef NS_ENUM(NSInteger,YfPreViewBeautifulFilter){
    
    YfPreViewBeautifulFilterNone = 0,           //无美颜效果
    YfPreViewBeautifulFilterGlobalBeauty,       //全局美颜
    YfPreViewBeautifulFilterLocalSkinBeauty,    //局部皮肤美颜
    
};

typedef NS_ENUM (NSInteger,YfPreViewBoxViewFilterFilter)
{
    
    YfPreViewBoxViewFilterFilterNone = 0, //
    YfPreViewBoxViewFilterFilterFour,    //4宫格
    YfPreViewBoxViewFilterFilterNine,    //9宫格
};


typedef NS_ENUM (NSInteger,YfPreViewMirrorFilter)
{
    YfPreViewMirrorFilterNone = 0,
    
    YfPreViewMirrorFilterUpDown,
    
    YfPreViewMirrorFilterRightLeft,
};


typedef NS_ENUM (NSInteger,YfPreViewSpecialFilter)
{
    YfPreViewSpecialFilterNone = 0,
    
    YfPreViewSpecialFilterLine,
    
    //YYfSessionCameraMirrorFilterRightLeft,
    
};

typedef NS_ENUM(NSInteger,YfImageOrientation){
    
    YfImageOrientationNormal = 0,           //直屏
    YfImageOrientationLandLeftFullScreen,   //左全屏
    YfImageOrientationLandRightFullScreen   //右全屏
    
};

typedef NS_ENUM(NSInteger,YfSessionPreViewFilter){
    
    
    //允许使用 不需要鉴权
    YfSessionPreViewFilterDefault = 0,             //default
    YfSessionPreViewFilterFishEye,                 //鱼眼
    YfSessionPreViewFilterConcaveMirror,           //凹面镜
    YfSessionPreViewFilterMagicMirror,             //哈哈镜
    YfSessionPreViewFilterGlassSphere,             //水晶球
    YfSessionPreViewFilterSwirl,                   //漩涡效果
    YfSessionPreViewFilterCameo,                   //浮雕
    YfSessionPreViewFilterVignette,                //晕影
    YfSessionPreViewFilterCartoon,                 //卡通

    
    YfSessionPreViewFilterMarz,                    //火星文
    YfSessionPreViewFilterCloud,                   //云雾
    YfSessionPreViewFilterColorOffSet,             //色彩偏移
    YfSessionPreViewFilterInterferenceEffect,      //随机噪点
    YfSessionPreViewFilterOrangeBlue,              //橘色化
    YfSessionPreViewFilterWave,                    //波浪
    
    //开销高
    YfSessionPreViewFilterBroken,                  //碎裂

    YfSessionPreViewFilterFakeRipple,              //重影抖动
    
    YfSessionPreViewFilterFakeHole,                //洞
    
    YfSessionPreViewFilterSobelLine,                //线条
    
    YfSessionPreViewFilterNightNoise,               //随机噪点抖动
    
    YfSessionPreViewFilterSeparateRGB,              //色彩分离
    
    

    YfSessionPreViewFilterRain,                 //下雨
     
    
    YfSessionPreViewFilterNightVision,             //夜视
    
    
    YfSessionPreViewFilterSevenTyLine,             //横纹
    
    
    //高开销
    YfSessionPreViewFilterBlackWhiteTV,            //黑白卡顿闪屏电视
    
    //高开销
    YfSessionPreViewFilterBlackColorTV,            //彩色卡顿闪屏电视
    
    //低开销
    YfSessionPreViewFilterBlackWhite2TV,            //黑白卡顿闪屏电视
    
    

    YfSessionPreViewFilterBokehBlur,                    //渐变模糊
    
    
    //高开销
    YfSessionPreViewFilterBroken2,                       //碎裂2
    
    
    //低开销 常规
    YfSessionPreViewFilterFourBoxFilterNormal,                //四宫格
    
    
    //低开销 特效
    YfSessionPreViewFilterFourBoxFilterSpecial,               //特效四宫格
    
    
    //低开销 常规
    YfSessionPreViewFilterNineBoxFilterNormal,                //九宫格
    
    
    //低开销 特效
    YfSessionPreViewFilterNineBoxFilterSpecial,                //九宫格
    
    //mpeg artfacts
    //MpegArtfacts
    YfSessionPreViewFilterMpegArtfacts,                   //MpegArtfacts
    
    
    YfSessionPreViewFilterAndroidWave,     //波浪
};


typedef enum {
    
    YFINSTCameraPreview_NORMAL_FILTER = 0,
    
    YFINSTCameraPreview_AMARO_FILTER,
    
    YFINSTCameraPreview_RISE_FILTER,
    
    YFINSTCameraPreview_HUDSON_FILTER,
    
    YFINSTCameraPreview_XPROII_FILTER,
    
    YFINSTCameraPreview_SIERRA_FILTER,
    
    YFINSTCameraPreview_LOMOFI_FILTER,
    
    YFINSTCameraPreview_EARLYBIRD_FILTER,
    
    YFINSTCameraPreview_SUTRO_FILTER,
    
    YFINSTCameraPreview_TOASTER_FILTER,
    
    YFINSTCameraPreview_BRANNAN_FILTER,
    
    YFINSTCameraPreview_INKWELL_FILTER,
    
    YFINSTCameraPreview_WALDEN_FILTER,
    
    YFINSTCameraPreview_HEFE_FILTER,
    
    YFINSTCameraPreview_VALENCIA_FILTER,
    
    YFINSTCameraPreview_NASHVILLE_FILTER,
    
    YFINSTCameraPreview_1977_FILTER,
    
    YFINSTCameraPreview_LORDKELVIN_FILTER,
    
    YFINSTCameraPreview_FILTER_TOTAL_NUMBER
    
} YFINSTCameraPreviewFilterType;


//未完善 不可用
typedef NS_ENUM(NSInteger,YfScenceFilter){
    
    YfScenceFilterNormal,               //正常
    YfScenceFilterSnow,   //雪花
    //YfScenceFilter   //右全屏

};


@protocol YfsessionPreViewDelegate <NSObject>

//输出rgba数据
- (void)willoutputpixelbuffer:(CVPixelBufferRef)pixelbuffer pts:(int64_t)pts;

@end

@interface YfsessionPreView : UIView

@property (nonatomic,weak)id<YfsessionPreViewDelegate>delegate;

@property (nonatomic,assign)int framerate;

- (instancetype) initWithFrame:(CGRect)frame outputbufferSize:(CGSize)size YfImageOrientation:(YfImageOrientation)YfImageOrientation;


#pragma mark  -----------------接受数据源------------------
/**
 *只能接收RGBA数据 弃用 ,新的替代方法（能够接收RGBA和YUV420） - (void)receiveYUVTextureBuffer:(CVPixelBufferRef)pixelbuffer pts:(int64_t)pts;
 *
 */
- (void)setPixelBuffer:(CVPixelBufferRef)pixelBuffer;

//接收数据源Y-U-V
- (void)receiveYUVTextureY:(void*)yData U:(void*)uData V:(void*)vData Ysize:(CGSize)Ysize Usize:(CGSize)Usize Vsize:(CGSize)Vsize videoSize:(CGSize)videoSize pts:(int64_t)pts;

//接收RGBA 和 YUV420 数据
- (void)receiveYUVTextureBuffer:(CVPixelBufferRef)pixelbuffer pts:(int64_t)pts;


- (void)cleanOuterDataSource;




#pragma mark -----------------GIF---------------------
//开启gif显示
-(void)decodeAndRenderWithFilePath:(NSString *)filePath PointRect:(CGRect)PointRect;
//关闭gif显示 && 释放
- (void)closeAndCleanGif;



#pragma mark -----------------水印---------------------
//弃用。  2017-8-18 替代方法 - (void)drawImageTexture:(NSString *)filePath PointRect:(CGRect)PointRect;
- (void)drawImageTexture:(NSString *)filePath PointSize:(YfPreviewViewLogoPostition)frameFrame;

- (void)drawImageTexture:(NSString *)filePath PointRect:(CGRect)PointRect;

- (void)releaseLogoTexture;


- (UIImage *)snapshot;

/**
 *释放
 */
- (void)releassePreview;

- (void)resetConfigure;

- (void)setScaleX:(float)xscale Y:(float)yscale Z:(float)zscale;


@property (nonatomic, assign)BOOL  isPlayerCameraMirror;


@property (nonatomic, assign)BOOL  snowSceneOpen;


/**
 *
 * 用于设置 YfPreViewBeautifulFilterGlobalBeauty
 */
//set beatiful rouguang 0.0 - 1.0  0.1
- (void)setRouGuangLevel:(float)RouGuangLevel;

//set beatiful Brighten 0.0 - 1.0    0.3
- (void)setBlurLevel:(float)BlurLevel;

//set beatiful saturation 0.0 - 1.0    0.3
- (void)setSaturationLevel:(float)SaturationLevel;

// Sharpness ranges from -4.0 to 4.0, with 0.0 as the normal level
- (void)setSharpnessLevel:(float)SharpnessLevel;
//亮度
- (void)setBrightNessLevel:(float)BrightNessLevel;

/**
 *
 * 用于设置 YfPreViewBeautifulFilterLocalSkinBeauty
 */
//色温
//The hue rotation is in the range [-360, 360] with 0 being no-change.
//default is 0.0
- (void)rotateHue:(float)h;

//饱和度
//The saturation adjustment is in the range [0.0, 2.0] with 1.0 being no-change.
//default is 1.0
- (void)adjustSaturation:(float)s;

//The brightness adjustment is in the range [0.0, 2.0] with 1.0 being no-change.
//default is 1.0;
- (void)adjustBrightness:(float)b;

//曝光度
// Exposure ranges from -10.0 to 10.0, with 0.0 as the normal level
//default is 0.0
- (void)adjustExposureness:(float)e;

//白平衡
//choose color temperature, in degrees Kelvin
//default 5000
- (void)adjustTemperatureness:(float)t;

//磨皮程度
//default is 3.8
- (void)adjustBlurness:(float)b;

//红润度
//The ruddiness adjustment is in the range [0.0, 1.0] with 0.0 being no-change.
//default is 0.3
- (void)adjustRuddiness:(float)r;

//设置特效
- (BOOL)setupFilter:(YfSessionPreViewFilter)filter;

//设置滤镜
- (void)switchFilter:(YFINSTCameraPreviewFilterType)type;

//切换美颜效果
- (void)switchBeautyFilter:(YfPreViewBeautifulFilter)BeautyFilter;


//设置宫格特效 注意 开销有点高 9宫格
- (void)switchBOXViewsFilter:(YfPreViewBoxViewFilterFilter)BoxViewFilterFilter;

//设置镜像特效
- (BOOL)switchMirrorFilter:(YfPreViewMirrorFilter)MirrorFilter;

//设置特殊滤镜
- (BOOL)switchSpecialFilter:(YfPreViewSpecialFilter)SpecialFilter;


//开启特效 残影       未开启鉴权 不让使用
- (BOOL)useSoulOBE:(BOOL)useSoulOBE;


//开启灵魂出窍效果。  
- (BOOL)useSoul:(BOOL)useSoul;
//抖动速率
//范围<0.0-2.0>    默认1.0
- (void)useSoulSpeed:(float)useSoulSpeed;

//录屏
- (void)PixelBufferCallBack:(BufferCallBack)PixelBufferCallBack;

//停止录屏
- (void)stopScreenRecord;


//选取几秒内 几张图片
- (void)createGifSnapShotDelayTime:(float)SnapShotDelayTime ImageCount:(int)ImageCount gifDelayTime:(float)delayTime gifFileName:(NSString*)gifFileName  gifCallBack:(GifCallBack)GifCallBack;

- (void)createGifImageArr:(NSArray<UIImage *> *)ImageArr gifDelayTime:(float)delayTime gifFileName:(NSString*)gifFileName  gifCallBack:(GifCallBack)GifCallBack;

//接受yuv和rgba

//接收视频水印Y-U-V数据
- (void)receiveYUVTextureY:(void*)yData U:(void*)uData V:(void*)vData Ysize:(CGSize)Ysize Usize:(CGSize)Usize Vsize:(CGSize)Vsize displayRect:(CGRect)displayRect Span:(int)spanSize;

//接收RGBA 和 YUV420 数据
- (void)receivePixelbufferTextureAtBufferIndex_0:(CVPixelBufferRef)piexelbuffer displayRect:(CGRect)displayRect;
- (void)CleanbufferTextureAtBufferIndex_0;

- (void)receivePixelbufferTextureAtBufferIndex_1:(CVPixelBufferRef)piexelbuffer displayRect:(CGRect)displayRect;
- (void)CleanbufferTextureAtBufferIndex_1;

- (void)receivePixelbufferTextureAtBufferIndex_2:(CVPixelBufferRef)piexelbuffer displayRect:(CGRect)displayRect;
- (void)CleanbufferTextureAtBufferIndex_2;

- (void)cleanAllYUVRGBAPixelbufferTexture;

@end
